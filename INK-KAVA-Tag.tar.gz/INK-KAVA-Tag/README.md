# INK-KAVA
Modern urban style with Ukrainian identity. Concrete-textured background with subtle embroidery. Cool grey tones with red/blue accents. Clean layout with sections: artists, price list, merch, and booking. Minimalist fonts. Mobile-friendly. Smooth scroll animations and ethnic details.
